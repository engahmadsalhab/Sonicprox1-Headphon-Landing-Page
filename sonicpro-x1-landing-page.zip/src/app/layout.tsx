import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "SONICPRO X1 | Ultimate Gaming Headphones",
  description: "Experience next-level gaming audio with SONICPRO X1. 7.1 surround sound, 50mm drivers, and RGB lighting for the ultimate immersive experience.",
  keywords: ["gaming headphones", "SONICPRO", "surround sound", "esports", "RGB gaming", "7.1 audio"],
  authors: [{ name: "SONICPRO" }],
  icons: {
    icon: "/headphone-hero.png",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className="dark" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
