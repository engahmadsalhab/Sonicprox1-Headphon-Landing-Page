'use client'

import { useEffect, useRef, useState } from 'react'
import { motion, useInView, useScroll, useTransform } from 'framer-motion'
import {
  Headphones, Volume2, Mic, Zap, Star, ChevronDown,
  Menu, X, Twitter, Youtube, Instagram, Facebook,
  Check, ArrowRight, MousePointer2
} from 'lucide-react'

/* ============================================
   ANIMATED COUNTER COMPONENT
   ============================================ */
function AnimatedCounter({ target, suffix = '', prefix = '' }: { target: number; suffix?: string; prefix?: string }) {
  const [count, setCount] = useState(0)
  const ref = useRef<HTMLSpanElement>(null)
  const isInView = useInView(ref, { once: true, margin: '-50px' })

  useEffect(() => {
    if (!isInView) return
    let start = 0
    const duration = 2000
    const startTime = performance.now()

    const animate = (currentTime: number) => {
      const elapsed = currentTime - startTime
      const progress = Math.min(elapsed / duration, 1)
      // Ease out cubic
      const eased = 1 - Math.pow(1 - progress, 3)
      start = Math.round(eased * target)
      setCount(start)
      if (progress < 1) {
        requestAnimationFrame(animate)
      }
    }
    requestAnimationFrame(animate)
  }, [isInView, target])

  return (
    <span ref={ref} className="tabular-nums">
      {prefix}{count.toLocaleString()}{suffix}
    </span>
  )
}

/* ============================================
   SECTION HEADER COMPONENT
   ============================================ */
function SectionHeader({ badge, title, subtitle }: { badge: string; title: string; subtitle: string }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-80px' }}
      transition={{ duration: 0.6, ease: 'easeOut' }}
      className="text-center mb-16"
    >
      <span className="inline-block px-4 py-1.5 text-xs font-semibold tracking-widest uppercase text-neon-cyan bg-neon-cyan/10 rounded-full border border-neon-cyan/20 mb-4">
        {badge}
      </span>
      <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold mb-4 bg-gradient-to-r from-white via-white to-white/60 bg-clip-text text-transparent">
        {title}
      </h2>
      <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
        {subtitle}
      </p>
    </motion.div>
  )
}

/* ============================================
   NAVBAR COMPONENT
   ============================================ */
function Navbar() {
  const [scrolled, setScrolled] = useState(false)
  const [mobileOpen, setMobileOpen] = useState(false)

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 50)
    window.addEventListener('scroll', handleScroll)
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  const navLinks = [
    { href: '#features', label: 'Features' },
    { href: '#specs', label: 'Specs' },
    { href: '#reviews', label: 'Reviews' },
    { href: '#pricing', label: 'Pricing' },
  ]

  return (
    <motion.nav
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      transition={{ duration: 0.6, ease: 'easeOut' }}
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled ? 'nav-blur border-b border-white/5 shadow-lg shadow-black/20' : 'bg-transparent'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 md:h-20">
          {/* Logo */}
          <a href="#" className="flex items-center gap-2 group">
            <Headphones className="w-7 h-7 text-neon-cyan transition-all duration-300 group-hover:drop-shadow-[0_0_8px_rgba(0,240,255,0.6)]" />
            <span className="text-xl font-bold tracking-tight">
              <span className="text-white">SONIC</span>
              <span className="text-neon-cyan">PRO</span>
            </span>
          </a>

          {/* Desktop Nav Links */}
          <div className="hidden md:flex items-center gap-8">
            {navLinks.map((link) => (
              <a
                key={link.href}
                href={link.href}
                className="text-sm text-muted-foreground hover:text-neon-cyan transition-colors duration-300 relative group"
              >
                {link.label}
                <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-neon-cyan transition-all duration-300 group-hover:w-full" />
              </a>
            ))}
          </div>

          {/* CTA Button */}
          <div className="hidden md:block">
            <a
              href="#pricing"
              className="btn-neon inline-flex items-center gap-2 px-5 py-2.5 text-sm font-semibold bg-neon-cyan/10 text-neon-cyan border border-neon-cyan/30 rounded-lg hover:bg-neon-cyan/20 transition-all duration-300"
            >
              Buy Now
              <ArrowRight className="w-4 h-4" />
            </a>
          </div>

          {/* Mobile Menu Toggle */}
          <button
            onClick={() => setMobileOpen(!mobileOpen)}
            className="md:hidden p-2 text-muted-foreground hover:text-neon-cyan transition-colors"
            aria-label="Toggle navigation menu"
          >
            {mobileOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {/* Mobile Menu */}
        {mobileOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden pb-4 border-t border-white/5"
          >
            <div className="flex flex-col gap-3 pt-4">
              {navLinks.map((link) => (
                <a
                  key={link.href}
                  href={link.href}
                  onClick={() => setMobileOpen(false)}
                  className="text-sm text-muted-foreground hover:text-neon-cyan px-3 py-2 rounded-lg hover:bg-white/5 transition-colors"
                >
                  {link.label}
                </a>
              ))}
              <a
                href="#pricing"
                onClick={() => setMobileOpen(false)}
                className="btn-neon inline-flex items-center justify-center gap-2 px-5 py-2.5 text-sm font-semibold bg-neon-cyan/10 text-neon-cyan border border-neon-cyan/30 rounded-lg mt-2"
              >
                Buy Now
                <ArrowRight className="w-4 h-4" />
              </a>
            </div>
          </motion.div>
        )}
      </div>
    </motion.nav>
  )
}

/* ============================================
   HERO SECTION
   ============================================ */
function HeroSection() {
  const ref = useRef<HTMLElement>(null)
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ['start start', 'end start']
  })
  const y = useTransform(scrollYProgress, [0, 1], [0, 150])
  const opacity = useTransform(scrollYProgress, [0, 0.8], [1, 0])

  return (
    <section ref={ref} className="relative min-h-screen flex items-center hero-gradient grid-bg overflow-hidden">
      {/* Animated background particles */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {[...Array(20)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute w-1 h-1 rounded-full bg-neon-cyan/30"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
            }}
            animate={{
              y: [0, -30, 0],
              opacity: [0.2, 0.8, 0.2],
            }}
            transition={{
              duration: 3 + Math.random() * 4,
              repeat: Infinity,
              delay: Math.random() * 3,
              ease: 'easeInOut',
            }}
          />
        ))}
      </div>

      <motion.div style={{ y, opacity }} className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-24 pb-16 md:pt-32 md:pb-24 w-full">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-8 items-center">
          {/* Text Content */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, ease: 'easeOut', delay: 0.2 }}
            className="text-center lg:text-left"
          >
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.4 }}
              className="inline-flex items-center gap-2 px-4 py-1.5 bg-neon-purple/10 border border-neon-purple/20 rounded-full mb-6"
            >
              <Zap className="w-3.5 h-3.5 text-neon-purple" />
              <span className="text-xs font-semibold text-neon-purple tracking-wide uppercase">New Release 2026</span>
            </motion.div>

            <h1 className="text-4xl sm:text-5xl lg:text-6xl xl:text-7xl font-bold leading-tight mb-6">
              <span className="bg-gradient-to-r from-white via-white to-white/80 bg-clip-text text-transparent">
                Dominate
              </span>
              <br />
              <span className="bg-gradient-to-r from-neon-cyan via-neon-purple to-neon-pink bg-clip-text text-transparent text-glow-cyan">
                Every Sound
              </span>
            </h1>

            <p className="text-lg md:text-xl text-muted-foreground mb-8 max-w-lg mx-auto lg:mx-0 leading-relaxed">
              The SONICPRO X1 delivers immersive 7.1 surround sound with 50mm titanium drivers, 
              adaptive noise cancellation, and customizable RGB lighting — engineered for champions.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
              <a
                href="#pricing"
                className="btn-neon inline-flex items-center justify-center gap-2 px-8 py-3.5 text-base font-bold bg-gradient-to-r from-neon-cyan to-cyan-400 text-dark-bg rounded-xl shadow-lg shadow-neon-cyan/20 hover:shadow-neon-cyan/40 transition-all duration-300"
              >
                Order Now — $199
                <ArrowRight className="w-5 h-5" />
              </a>
              <a
                href="#features"
                className="inline-flex items-center justify-center gap-2 px-8 py-3.5 text-base font-semibold text-white/80 border border-white/10 rounded-xl hover:bg-white/5 hover:border-white/20 transition-all duration-300"
              >
                Explore Features
                <ChevronDown className="w-4 h-4" />
              </a>
            </div>

            {/* Quick Stats */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.8 }}
              className="flex gap-8 mt-10 justify-center lg:justify-start"
            >
              {[
                { value: '50', suffix: 'mm', label: 'Drivers' },
                { value: '7.1', suffix: '', label: 'Surround' },
                { value: '40', suffix: 'hr', label: 'Battery' },
              ].map((stat) => (
                <div key={stat.label} className="text-center">
                  <div className="text-2xl font-bold text-neon-cyan">{stat.value}{stat.suffix}</div>
                  <div className="text-xs text-muted-foreground mt-1">{stat.label}</div>
                </div>
              ))}
            </motion.div>
          </motion.div>

          {/* Product Image */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, ease: 'easeOut', delay: 0.4 }}
            className="relative flex justify-center lg:justify-end"
          >
            <div className="relative">
              {/* Glow rings behind the image */}
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="w-72 h-72 sm:w-80 sm:h-80 lg:w-96 lg:h-96 rounded-full bg-neon-cyan/5 blur-3xl animate-pulse" />
              </div>
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="w-56 h-56 sm:w-64 sm:h-64 lg:w-80 lg:h-80 rounded-full bg-neon-purple/5 blur-3xl animate-pulse" style={{ animationDelay: '1.5s' }} />
              </div>
              
              <motion.div
                animate={{ y: [-8, 8, -8] }}
                transition={{ duration: 5, repeat: Infinity, ease: 'easeInOut' }}
                className="relative z-10"
              >
                <img
                  src="/headphone-hero.png"
                  alt="SONICPRO X1 Gaming Headphones - Premium 7.1 surround sound headset with RGB lighting"
                  className="w-72 h-72 sm:w-80 sm:h-80 lg:w-[420px] lg:h-[420px] object-contain hero-image-glow"
                  priority
                />
              </motion.div>
            </div>
          </motion.div>
        </div>
      </motion.div>

      {/* Scroll indicator */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.5 }}
        className="absolute bottom-8 left-1/2 -translate-x-1/2"
      >
        <motion.div
          animate={{ y: [0, 8, 0] }}
          transition={{ duration: 2, repeat: Infinity, ease: 'easeInOut' }}
          className="flex flex-col items-center gap-2 text-muted-foreground"
        >
          <span className="text-xs tracking-widest uppercase">Scroll</span>
          <MousePointer2 className="w-4 h-4" />
        </motion.div>
      </motion.div>
    </section>
  )
}

/* ============================================
   FEATURES SECTION
   ============================================ */
function FeaturesSection() {
  const features = [
    {
      icon: Volume2,
      title: '7.1 Virtual Surround',
      description: 'Hear every footstep, reload, and callout with pinpoint precision. Our proprietary spatial audio engine delivers true positional awareness that gives you the competitive edge in every match.',
      color: 'neon-cyan',
      gradient: 'from-neon-cyan/20 to-cyan-500/20',
    },
    {
      icon: Headphones,
      title: '50mm Titanium Drivers',
      description: 'Custom-tuned 50mm titanium-coated drivers deliver deep, thunderous bass and crystal-clear highs. Experience audio fidelity that brings your games to life with stunning realism and detail.',
      color: 'neon-purple',
      gradient: 'from-neon-purple/20 to-purple-500/20',
    },
    {
      icon: Mic,
      title: 'AI Noise-Cancelling Mic',
      description: 'Our AI-powered beamforming microphone isolates your voice from background chaos. Teammates hear you loud and clear, even in the noisiest environments — no more repeating callouts.',
      color: 'neon-pink',
      gradient: 'from-neon-pink/20 to-pink-500/20',
    },
    {
      icon: Zap,
      title: '40-Hour Battery Life',
      description: 'Game marathon sessions without interruption. The optimized power management system delivers 40 hours of continuous use on a single charge, with quick-charge support for 5 hours of play in just 15 minutes.',
      color: 'neon-green',
      gradient: 'from-neon-green/20 to-green-500/20',
    },
  ]

  return (
    <section id="features" className="relative py-24 md:py-32 overflow-hidden">
      {/* Background accent */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-4xl h-px bg-gradient-to-r from-transparent via-neon-cyan/20 to-transparent" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <SectionHeader
          badge="Features"
          title="Built for Victory"
          subtitle="Every feature is engineered to give you the competitive advantage you need to dominate the battlefield."
        />

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {features.map((feature, index) => (
            <motion.div
              key={feature.title}
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-50px' }}
              transition={{ duration: 0.5, delay: index * 0.1, ease: 'easeOut' }}
              className="feature-card rounded-2xl bg-dark-card p-6 relative group"
            >
              {/* Gradient accent on top */}
              <div className={`absolute top-0 left-0 right-0 h-px bg-gradient-to-r ${feature.gradient} opacity-60`} />

              <div className={`feature-icon inline-flex items-center justify-center w-12 h-12 rounded-xl bg-${feature.color}/10 mb-5`}>
                <feature.icon className={`w-6 h-6 text-${feature.color}`} />
              </div>

              <h3 className="text-lg font-bold text-white mb-3">{feature.title}</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">{feature.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}

/* ============================================
   SPECIFICATIONS SECTION
   ============================================ */
function SpecsSection() {
  const specs = [
    { label: 'Driver Size', value: '50mm', detail: 'Titanium-Coated' },
    { label: 'Frequency Response', value: '20Hz', detail: 'to 40kHz' },
    { label: 'Impedance', value: '32Ω', detail: 'Low Impedance' },
    { label: 'Sensitivity', value: '108dB', detail: 'SPL @ 1kHz' },
    { label: 'Battery Life', value: '40hrs', detail: 'Continuous Play' },
    { label: 'Charging', value: 'USB-C', detail: 'Quick Charge' },
    { label: 'Weight', value: '298g', detail: 'Ultra Lightweight' },
    { label: 'Connectivity', value: '2.4GHz', detail: '+ Bluetooth 5.3' },
    { label: 'Surround Sound', value: '7.1ch', detail: 'Virtual Surround' },
    { label: 'Microphone', value: 'AI-Powered', detail: 'Beamforming' },
    { label: 'RGB Zones', value: '3 Zones', detail: '16.8M Colors' },
    { label: 'Latency', value: '<1ms', detail: '2.4GHz Wireless' },
  ]

  return (
    <section id="specs" className="relative py-24 md:py-32 overflow-hidden">
      {/* Background glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-neon-purple/5 rounded-full blur-[120px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <SectionHeader
          badge="Specifications"
          title="Technical Excellence"
          subtitle="Precision-engineered components deliver uncompromising audio performance and lasting comfort."
        />

        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Product Image */}
          <motion.div
            initial={{ opacity: 0, x: -40 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: '-80px' }}
            transition={{ duration: 0.6 }}
            className="relative flex justify-center"
          >
            <div className="relative">
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="w-64 h-64 lg:w-80 lg:h-80 rounded-full bg-neon-purple/5 blur-3xl" />
              </div>
              <motion.img
                src="/headphone-spec.png"
                alt="SONICPRO X1 Technical Specifications - Side view showing driver and microphone details"
                className="relative z-10 w-64 h-64 lg:w-80 lg:h-80 object-contain hero-image-glow"
                animate={{ y: [-5, 5, -5] }}
                transition={{ duration: 4, repeat: Infinity, ease: 'easeInOut' }}
              />
            </div>
          </motion.div>

          {/* Specs Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
            {specs.map((spec, index) => (
              <motion.div
                key={spec.label}
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true, margin: '-30px' }}
                transition={{ duration: 0.4, delay: index * 0.05 }}
                className="spec-item p-4 rounded-xl bg-dark-card text-center"
              >
                <div className="text-xs text-muted-foreground mb-1 uppercase tracking-wider">{spec.label}</div>
                <div className="text-xl font-bold text-neon-cyan">{spec.value}</div>
                <div className="text-xs text-muted-foreground/70 mt-0.5">{spec.detail}</div>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Animated Counters */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="mt-20 grid grid-cols-2 md:grid-cols-4 gap-6"
        >
          {[
            { target: 50000, suffix: '+', label: 'Units Sold', prefix: '' },
            { target: 4, suffix: '.9', label: 'Avg Rating', prefix: '' },
            { target: 120, suffix: '+', label: 'Pro Teams', prefix: '' },
            { target: 98, suffix: '%', label: 'Satisfaction', prefix: '' },
          ].map((stat) => (
            <div key={stat.label} className="text-center p-6 rounded-xl bg-dark-card border border-dark-border">
              <div className="text-3xl md:text-4xl font-bold text-neon-cyan mb-2">
                <AnimatedCounter target={stat.target} suffix={stat.suffix} prefix={stat.prefix} />
              </div>
              <div className="text-sm text-muted-foreground">{stat.label}</div>
            </div>
          ))}
        </motion.div>
      </div>
    </section>
  )
}

/* ============================================
   REVIEWS / TESTIMONIALS SECTION
   ============================================ */
function ReviewsSection() {
  const reviews = [
    {
      name: 'Alex "Phantom" Chen',
      role: 'Pro FPS Player',
      avatar: 'PC',
      rating: 5,
      text: 'The spatial audio on the SONICPRO X1 is absolutely game-changing. I can pinpoint enemy positions with surgical precision. This headset has genuinely improved my competitive performance and K/D ratio.',
    },
    {
      name: 'Sarah Mitchell',
      role: 'Twitch Streamer',
      avatar: 'SM',
      rating: 5,
      text: 'As a streamer, I need reliable audio for hours on end. The 40-hour battery and AI noise cancellation mean my viewers hear me clearly every stream. The RGB lighting looks incredible on camera too.',
    },
    {
      name: 'Marcus Rodriguez',
      role: 'Esports Coach',
      avatar: 'MR',
      rating: 5,
      text: 'I\'ve equipped my entire team with the SONICPRO X1. The zero-latency wireless and surround sound give us the communication clarity we need in tournaments. Worth every penny for competitive play.',
    },
    {
      name: 'Jin Park',
      role: 'Audio Engineer',
      avatar: 'JP',
      rating: 5,
      text: 'From an audiophile perspective, the 50mm titanium drivers produce remarkably accurate sound reproduction. The frequency response extends beautifully across the entire range. Impressive for a gaming headset.',
    },
    {
      name: 'Taylor Brooks',
      role: 'Content Creator',
      avatar: 'TB',
      rating: 4,
      text: 'The build quality is exceptional — premium materials that feel like they\'ll last years. The memory foam ear cushions are incredibly comfortable during my 8-hour editing sessions. Superb comfort.',
    },
    {
      name: 'David "Striker" Kim',
      role: 'Battle Royale Champion',
      avatar: 'DK',
      rating: 5,
      text: 'Switched from my old headset and the difference is night and day. The surround sound gives me a huge advantage in battle royale games. I can hear enemies before they even know I\'m there.',
    },
  ]

  return (
    <section id="reviews" className="relative py-24 md:py-32 overflow-hidden">
      {/* Background accent */}
      <div className="absolute top-1/2 right-0 w-[400px] h-[400px] bg-neon-pink/5 rounded-full blur-[100px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <SectionHeader
          badge="Reviews"
          title="Loved by Gamers"
          subtitle="Join thousands of gamers and professionals who trust SONICPRO X1 for their daily audio needs."
        />

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {reviews.map((review, index) => (
            <motion.div
              key={review.name}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-50px' }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="review-card rounded-2xl bg-dark-card p-6 relative"
            >
              {/* Stars */}
              <div className="flex gap-1 mb-4">
                {[...Array(5)].map((_, i) => (
                  <Star
                    key={i}
                    className={`w-4 h-4 ${i < review.rating ? 'star-filled fill-current' : 'text-muted-foreground/30'}`}
                  />
                ))}
              </div>

              <p className="text-sm text-white/80 leading-relaxed mb-6">{review.text}</p>

              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-gradient-to-br from-neon-cyan/20 to-neon-purple/20 border border-white/10 flex items-center justify-center text-xs font-bold text-neon-cyan">
                  {review.avatar}
                </div>
                <div>
                  <div className="text-sm font-semibold text-white">{review.name}</div>
                  <div className="text-xs text-muted-foreground">{review.role}</div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}

/* ============================================
   PRICING SECTION
   ============================================ */
function PricingSection() {
  const plans = [
    {
      name: 'Standard',
      price: '$149',
      description: 'Essential gaming audio for casual players',
      features: [
        'Stereo Audio (2.0ch)',
        '40mm Standard Drivers',
        'Wired Connection Only',
        'Detachable Boom Mic',
        'On-Ear Volume Control',
        '1-Year Warranty',
      ],
      featured: false,
      cta: 'Get Standard',
    },
    {
      name: 'X1 Pro',
      price: '$199',
      description: 'The ultimate gaming experience — our flagship',
      features: [
        '7.1 Virtual Surround Sound',
        '50mm Titanium Drivers',
        '2.4GHz Wireless + Bluetooth 5.3',
        'AI Noise-Cancelling Mic',
        'Customizable RGB (3 Zones)',
        '40-Hour Battery Life',
        'Quick Charge (15min = 5hr)',
        '2-Year Warranty',
      ],
      featured: true,
      cta: 'Get X1 Pro',
      badge: 'Most Popular',
    },
    {
      name: 'Team Pack',
      price: '$749',
      description: '5 X1 Pro units for your squad — save $246',
      features: [
        '5x SONICPRO X1 Pro Headsets',
        'Team-Sync Software License',
        'Custom Team RGB Profiles',
        'Priority Tournament Support',
        'Dedicated Account Manager',
        '3-Year Extended Warranty',
      ],
      featured: false,
      cta: 'Get Team Pack',
    },
  ]

  return (
    <section id="pricing" className="relative py-24 md:py-32 overflow-hidden">
      {/* Background accents */}
      <div className="absolute top-0 left-0 w-[500px] h-[500px] bg-neon-cyan/5 rounded-full blur-[120px] pointer-events-none" />
      <div className="absolute bottom-0 right-0 w-[500px] h-[500px] bg-neon-purple/5 rounded-full blur-[120px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <SectionHeader
          badge="Pricing"
          title="Choose Your Arsenal"
          subtitle="Select the perfect package for your gaming needs. Free shipping on all orders."
        />

        <div className="grid md:grid-cols-3 gap-6 lg:gap-8 items-start">
          {plans.map((plan, index) => (
            <motion.div
              key={plan.name}
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-50px' }}
              transition={{ duration: 0.5, delay: index * 0.15 }}
              className={`pricing-card rounded-2xl bg-dark-card p-6 lg:p-8 relative ${
                plan.featured ? 'featured ring-1 ring-neon-cyan/20' : ''
              }`}
            >
              {plan.badge && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-4 py-1 bg-gradient-to-r from-neon-cyan to-cyan-400 text-dark-bg text-xs font-bold rounded-full">
                  {plan.badge}
                </div>
              )}

              <div className="text-center mb-6">
                <h3 className="text-xl font-bold text-white mb-1">{plan.name}</h3>
                <p className="text-sm text-muted-foreground mb-4">{plan.description}</p>
                <div className="flex items-baseline justify-center gap-1">
                  <span className="text-4xl lg:text-5xl font-bold text-white">{plan.price}</span>
                </div>
              </div>

              <div className="neon-line mb-6" />

              <ul className="space-y-3 mb-8">
                {plan.features.map((feature) => (
                  <li key={feature} className="flex items-start gap-3 text-sm text-white/70">
                    <Check className={`w-4 h-4 mt-0.5 shrink-0 ${plan.featured ? 'text-neon-cyan' : 'text-muted-foreground'}`} />
                    <span>{feature}</span>
                  </li>
                ))}
              </ul>

              <button
                className={`btn-neon w-full py-3 rounded-xl font-semibold text-sm transition-all duration-300 ${
                  plan.featured
                    ? 'bg-gradient-to-r from-neon-cyan to-cyan-400 text-dark-bg hover:shadow-lg hover:shadow-neon-cyan/25'
                    : 'bg-white/5 text-white border border-white/10 hover:bg-white/10 hover:border-white/20'
                }`}
              >
                {plan.cta}
              </button>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}

/* ============================================
   FOOTER COMPONENT
   ============================================ */
function Footer() {
  const footerLinks = {
    Product: ['Features', 'Specifications', 'Pricing', 'Accessories', 'Software'],
    Support: ['Help Center', 'Warranty', 'Returns', 'Contact Us', 'Firmware Updates'],
    Company: ['About', 'Careers', 'Press', 'Blog', 'Partnerships'],
    Legal: ['Privacy Policy', 'Terms of Service', 'Cookie Policy', 'Accessibility'],
  }

  return (
    <footer className="relative border-t border-white/5 bg-dark-bg">
      {/* Top neon line */}
      <div className="neon-line" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-2 md:grid-cols-5 gap-8 lg:gap-12">
          {/* Brand Column */}
          <div className="col-span-2 md:col-span-1">
            <a href="#" className="flex items-center gap-2 mb-4">
              <Headphones className="w-6 h-6 text-neon-cyan" />
              <span className="text-lg font-bold">
                <span className="text-white">SONIC</span>
                <span className="text-neon-cyan">PRO</span>
              </span>
            </a>
            <p className="text-sm text-muted-foreground mb-6 leading-relaxed">
              Engineered for champions. Premium gaming audio that gives you the edge in every battle.
            </p>

            {/* Social Links */}
            <div className="flex gap-3">
              {[
                { icon: Twitter, label: 'Twitter' },
                { icon: Youtube, label: 'YouTube' },
                { icon: Instagram, label: 'Instagram' },
                { icon: Facebook, label: 'Facebook' },
              ].map((social) => (
                <a
                  key={social.label}
                  href="#"
                  aria-label={social.label}
                  className="w-9 h-9 rounded-lg bg-white/5 border border-white/5 flex items-center justify-center text-muted-foreground hover:text-neon-cyan hover:border-neon-cyan/20 hover:bg-neon-cyan/5 transition-all duration-300"
                >
                  <social.icon className="w-4 h-4" />
                </a>
              ))}
            </div>
          </div>

          {/* Link Columns */}
          {Object.entries(footerLinks).map(([category, links]) => (
            <div key={category}>
              <h4 className="text-sm font-semibold text-white mb-4">{category}</h4>
              <ul className="space-y-2.5">
                {links.map((link) => (
                  <li key={link}>
                    <a href="#" className="text-sm text-muted-foreground hover:text-neon-cyan transition-colors duration-200">
                      {link}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Bottom Bar */}
        <div className="mt-12 pt-8 border-t border-white/5 flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-xs text-muted-foreground">
            &copy; {new Date().getFullYear()} SONICPRO. All rights reserved.
          </p>
          <div className="flex items-center gap-6">
            <span className="text-xs text-muted-foreground">Designed for gamers, by gamers.</span>
          </div>
        </div>
      </div>
    </footer>
  )
}

/* ============================================
   MAIN PAGE COMPONENT
   ============================================ */
export default function Home() {
  return (
    <div className="min-h-screen flex flex-col bg-dark-bg">
      <Navbar />
      <main className="flex-1">
        <HeroSection />
        <FeaturesSection />
        <SpecsSection />
        <ReviewsSection />
        <PricingSection />
      </main>
      <Footer />
    </div>
  )
}
